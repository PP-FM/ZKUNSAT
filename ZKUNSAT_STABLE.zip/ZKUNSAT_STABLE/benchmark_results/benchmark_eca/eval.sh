for FILE in ./instance/*.unfold; do  ../test $1 12345 "$FILE"; done
