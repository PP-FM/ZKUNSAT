for FILE in ./instance/*.unfold.gz; 
do   
       	size=$(stat --printf="%s" "$FILE")
       	if [ $size -gt 2000000 ]; then
	       	continue
	gzip -d "$FILE"
	../test $1 12345 "${FILE::-3}"
	gzip "${FILE::-3}"
done
